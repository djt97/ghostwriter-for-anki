# Ghostwriter for Anki Privacy Policy

This policy now lives in [PRIVACY_POLICY.md](PRIVACY_POLICY.md). Please refer to the canonical policy there.
